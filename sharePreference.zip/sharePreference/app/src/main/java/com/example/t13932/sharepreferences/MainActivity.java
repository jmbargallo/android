package com.example.t13932.sharepreferences;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

  private EditText textoGuardar;
  private static final String FILENAME = "data.txt";
  private Button butonLeer;
  private TextView txtLeer;
  private TextView buttonEliminar;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
    setSupportActionBar(toolbar);

    textoGuardar = (EditText) findViewById(R.id.et_guardar);
    butonLeer = (Button) findViewById(R.id.button);
    txtLeer = (TextView) findViewById(R.id.textView);
    buttonEliminar = (TextView)findViewById(R.id.button2);
    buttonEliminar.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        //Delete the created file
        txtLeer.setText("");
        deleteFile(FILENAME);
      }
    });


    butonLeer.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        leerFichero(txtLeer);
      }
    });


    FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
    fab.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        //Create a new file and write some data
        try {
          FileOutputStream mOutput = openFileOutput(FILENAME, Activity.MODE_PRIVATE);
          mOutput.write(textoGuardar.getText().toString().getBytes());
          mOutput.flush();
          mOutput.close();
        } catch (FileNotFoundException e) {
          e.printStackTrace();
          Log.e("manel","error en guardar "+e.getMessage());
        } catch (IOException e) {
          e.printStackTrace();
          Log.e("manel","error en guardar "+e.getMessage());
        }
      }
    });
  }

  private void leerFichero(TextView txtLeer) {
    //Read the created file and display to the screen
    try {
      FileInputStream mInput = openFileInput(FILENAME);
      byte[] data = new byte[128];
      mInput.read(data);
      mInput.close();
      String display = new String(data);
      txtLeer.setText(display.trim());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      txtLeer.setText(e.getMessage());
    } catch (IOException e) {
      txtLeer.setText(e.getMessage());
    }
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.menu_main, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    // Handle action bar item clicks here. The action bar will
    // automatically handle clicks on the Home/Up button, so long
    // as you specify a parent activity in AndroidManifest.xml.
    int id = item.getItemId();

    //noinspection SimplifiableIfStatement
    if (id == R.id.action_settings) {
      return true;
    }

    return super.onOptionsItemSelected(item);
  }
}
