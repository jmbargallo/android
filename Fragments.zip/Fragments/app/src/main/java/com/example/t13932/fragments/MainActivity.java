package com.example.t13932.fragments;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, BlankFragment.OnListenerName {

  private EditText etName;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    //1 Necesitamos las referencias
     etName = (EditText) findViewById(R.id.activity_et_nombre);


    Button btnFragment = (Button) findViewById(R.id.activity_btn_insFragment);
    btnFragment.setOnClickListener(this);



  }

  @Override
  public void onClick(View view) {
    switch (view.getId()){
      case R.id.activity_btn_insFragment:
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.activity_root_fragment,BlankFragment.newInstance(etName.getText().toString()))
                .commitAllowingStateLoss();
    }
  }

  @Override
  public void listenerName(String name) {
    Log.e(MainActivity.class.getName(),"EL RESULTADO ES: "+name);
  }
}
