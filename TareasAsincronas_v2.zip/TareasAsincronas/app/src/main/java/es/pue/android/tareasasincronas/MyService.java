package es.pue.android.tareasasincronas;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MyService extends Service {

    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        String url_to_load = intent.getStringExtra("url_load");
        new DescargarCodigoPaginaWebTask().execute(url_to_load);
        return Service.START_NOT_STICKY;
    }

    private class DescargarCodigoPaginaWebTask
            extends AsyncTask<String,Void,String>
    {
        @Override
        protected String doInBackground(String... urls) {

            OkHttpClient cliente = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(urls[0])
                    .build();
            try {
                Response respuesta = cliente.newCall(request).execute();
                if (respuesta.isSuccessful()){
                    return respuesta.body().string();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return "Sin codigo";

        }

        @Override
        protected void onPostExecute(String codigoHmtl) {
            //txData.setText(codigoHmtl);
            Log.i("SERVICE",codigoHmtl);
            Intent i = new Intent();
            i.setAction("es.pue.android.tareasasincronas.DATOS_OK");
            i.putExtra("html",codigoHmtl);
            sendBroadcast(i);
        }
    }
}
