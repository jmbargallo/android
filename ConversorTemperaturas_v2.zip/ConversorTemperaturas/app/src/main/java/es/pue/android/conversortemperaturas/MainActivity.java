package es.pue.android.conversortemperaturas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import es.pue.android.conversortemperaturas.calculos.Conversor;
import es.pue.android.conversortemperaturas.calculos.TiposConversion;

public class MainActivity extends AppCompatActivity {

    private TextView resultado;
    private EditText etValorEntrada;
    private Conversor conversor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //instanciar conversor
        conversor = new Conversor();

        resultado = (TextView) findViewById(R.id.tvResultado);
        //resultado.setText("Prueba resultado");

        etValorEntrada= (EditText) findViewById(R.id.etTemperatura);

    }

    private void calcular(TiposConversion tipoConv){
        String valorAConvertir = etValorEntrada.getText().toString();
        Log.i("CONVERSOR_ACTIViTY",valorAConvertir);

        //F2C
        //(valor-entrada - 32 * 5) / 9
        conversor.convertir(Float.valueOf(valorAConvertir),
                tipoConv);

    }

    public void convertir(View v){



        Toast.makeText(this,
                "Conversor de Temp",
                Toast.LENGTH_LONG).show();


        calcular(TiposConversion.F2C);
        float resultadoConversion = conversor.getValorSalida();
        resultado.setText(String.valueOf(resultadoConversion));
    }


    @Override
    protected void onStop() {
        super.onStop();
        Log.i("LOG_APP","Stop Activity");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("LOG_APP","Restart Activity");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("LOG_APP","Start Activity");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("LOG_APP","Resume Activity");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("LOG_APP","Destroy Activity");
    }

    public void convertirC2K(View view) {
        calcular(TiposConversion.C2K);
        float resultadoConversion = conversor.getValorSalida();
        resultado.setText(String.valueOf(resultadoConversion));
    }
}