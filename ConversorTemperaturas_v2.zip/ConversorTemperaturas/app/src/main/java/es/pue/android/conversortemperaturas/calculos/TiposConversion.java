package es.pue.android.conversortemperaturas.calculos;

public enum TiposConversion {
    F2C,
    C2K
}
