package es.pue.android.conversortemperaturas.calculos;

import android.util.Log;

public class Conversor {

    private float valorEntrada;
    private float valorSalida;

    public float getValorEntrada() {
        return valorEntrada;
    }

    public float getValorSalida() {
        return valorSalida;
    }

    private float f2c(float v){
        return (v - 32.0f) * 5.0f / 9.0f;
    }

    private float c2k(float v){
        return v + 273.15f;
    }

    //API
    public void convertir(float valor,TiposConversion conv){

        switch (conv){
            case F2C:
                this.valorSalida = f2c(valor);
                break;
            case C2K:
                this.valorSalida = c2k(valor);
                break;
            default:
                Log.i("CONVERSION_APP","Conversion no valida");

        }

    }
}
