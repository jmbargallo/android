package es.pue.android.mapas;

import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MapActivity extends AppCompatActivity {

    Button btnMap;

    //datos
    //List<String> ciudades = new ArrayList<>();

    //1.- Crear la nueva estructura (Map)
    //2.- Determinar qué clave usaremos
    //3.- Determinar el valor objeto DatosGeo

    Map<String,DatosGeo> ciudadesDiccio= new HashMap<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        Intent i = getIntent();
        Parcelable datosParcelable = i.getParcelableExtra("datosG");
        final DatosGeo dGeo = (DatosGeo) datosParcelable;

        btnMap = (Button)findViewById(R.id.btnMap);

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMap(Double.valueOf(dGeo.getLatitud()),
                            Double.valueOf(dGeo.getLongitud()));
            }
        });

        //generra info de ciudades
        /*
        ciudades.add("Barcelona");
        ciudades.add("Basilea");
        ciudades.add("Berlin");
        ciudades.add("Madrid");
        ciudades.add("Lucerna");
        */
        cargarDatos(); //carga de diccinario ciudadesDiccio
        Set<String> claves = ciudadesDiccio.keySet();

        final List<String> ciudades = new ArrayList<>(claves);


        ListView listaCiudades = (ListView) findViewById(R.id.lstCities);

        //listener
        AdapterView.OnItemClickListener listener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MapActivity.this,ciudades.get(position),Toast.LENGTH_SHORT).show();
            }
        };

        listaCiudades.setOnItemClickListener(listener);

        //creacion de adaptador
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                                R.layout.item_list,R.id.textView1,ciudades);

        listaCiudades.setAdapter(adapter);

    }
    private void showMap(double latitude, double longitud){

        Intent i = new Intent();
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse("geo:" + latitude + "," + longitud));
        startActivity(i);
    }

    private void cargarDatos(){
        ciudadesDiccio.put("Barcelona",
                new DatosGeo(String.valueOf(41.3947688),
                        String.valueOf(2.0787282)));

        ciudadesDiccio.put("Madrid",
                new DatosGeo(String.valueOf(40.4378698  ),
                        String.valueOf(-3.8196196)));

        ciudadesDiccio.put("Santiago",
                new DatosGeo(String.valueOf(42.8801996  ),
                        String.valueOf(-8.579789)));

        ciudadesDiccio.put("Santander",
                new DatosGeo(String.valueOf(42.8801889  ),
                        String.valueOf(-8.579789)));
    }
}
