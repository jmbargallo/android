package com.example.t13932.fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BlankFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BlankFragment extends Fragment {

  //1) CONSTRUIR LA INTERFACE

  public interface OnListenerName {
    void listenerName(String name);
  }

  //2) Traernos la referencia del Objeto Listener-La interface-
  private OnListenerName listenerName;

  private static final String ARG_NAME = "NAME";
  private String name;


  public BlankFragment() {
    // Required empty public constructor
  }

  /**
   * Use this factory method to create a new instance of
   * this fragment using the provided parameters.
   *
   * @param name Parameter 1.
   * @return A new instance of fragment BlankFragment.
   */
  public static BlankFragment newInstance(String name) {
    BlankFragment fragment = new BlankFragment();
    Bundle args = new Bundle();
    args.putString(ARG_NAME, name);
    fragment.setArguments(args);
    return fragment;
  }

  @Override
  public void onAttach(Context context) {
    super.onAttach(context);
    if (context instanceof OnListenerName) {
      listenerName = (OnListenerName) context;
    } else {
      throw new RuntimeException(context.toString()
              + " must implement OnListenerName");
    }
  }

  @Override
  public void onDetach() {
    super.onDetach();
    listenerName = null;
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (getArguments() != null) {
      name = getArguments().getString(ARG_NAME);
    }
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container,
                           Bundle savedInstanceState) {
    // Inflate the layout for this fragment
    View layout = inflater.inflate(R.layout.fragment_blank, container, false);
    TextView txtName = (TextView) layout.findViewById(R.id.blankfragment_txt_name);
    txtName.setText(name);

    if (listenerName != null) {
      listenerName.listenerName(name+"1");
    }

    return layout;
  }

}
