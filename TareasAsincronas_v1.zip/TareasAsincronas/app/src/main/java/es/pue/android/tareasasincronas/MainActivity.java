package es.pue.android.tareasasincronas;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    TextView txData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txData = (TextView)findViewById(R.id.tvCode);


    }

    public void loadCode(View view) {
        //cargar asíncronamente el codigo html de cualquier pagina pasada
        new DescargarCodigoPaginaWebTask().execute("http://www.elpais.es");
    }

    private class DescargarCodigoPaginaWebTask
            extends AsyncTask<String,Void,String>
    {
        @Override
        protected String doInBackground(String... urls) {

            OkHttpClient cliente = new OkHttpClient();
            Request request = new Request.Builder()
                                .url(urls[0])
                                .build();
            try {
                Response respuesta = cliente.newCall(request).execute();
                if (respuesta.isSuccessful()){
                    return respuesta.body().string();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return "Sin codigo";

        }

        @Override
        protected void onPostExecute(String codigoHmtl) {
            txData.setText(codigoHmtl);
        }
    }
}
