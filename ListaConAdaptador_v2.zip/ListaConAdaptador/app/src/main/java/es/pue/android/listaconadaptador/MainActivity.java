package es.pue.android.listaconadaptador;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> paises = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //cargar paises desde xml
        setUpInfoPaises();

        ListView lvCountry = (ListView)findViewById(R.id.country_list);
        CountryAdapter adapter =
                new CountryAdapter(this,
                            R.layout.list_item,
                                            paises);
        lvCountry.setAdapter(adapter);
    }

    private void setUpInfoPaises(){
        paises = Arrays.asList(getResources().getStringArray(R.array.countries));
    }
}
