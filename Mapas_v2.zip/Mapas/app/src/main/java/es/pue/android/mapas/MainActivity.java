package es.pue.android.mapas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText etLongitude;
    EditText etLatitude;

    DatosGeo datosGeo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etLatitude = (EditText)findViewById(R.id.etLatitude);
        etLongitude = (EditText)findViewById(R.id.etLongitude);

        Button btnInfo = (Button) findViewById(R.id.btnSendInfo);

        btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datosGeo = getData();
                sendInfo(datosGeo);
            }
        });


    }

    private DatosGeo getData(){
        String latitud = etLatitude.getText().toString();
        String longitud = etLongitude.getText().toString();

        DatosGeo dg = new DatosGeo(latitud,longitud);
        return dg;

    }

    private void sendInfo(DatosGeo info){
        Intent i = new Intent(this,MapActivity.class);
        i.putExtra("datosG",info);
        startActivity(i);
    }
}
