package es.pue.android.mapas;

import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MapActivity extends AppCompatActivity {

    Button btnMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        Intent i = getIntent();
        Parcelable datosParcelable = i.getParcelableExtra("datosG");
        final DatosGeo dGeo = (DatosGeo) datosParcelable;

        btnMap = (Button)findViewById(R.id.btnMap);

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMap(Double.valueOf(dGeo.getLatitud()),
                            Double.valueOf(dGeo.getLongitud()));
            }
        });





    }
    private void showMap(double latitude, double longitud){

        Intent i = new Intent();
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse("geo:" + latitude + "," + longitud));
        startActivity(i);
    }
}
