package es.pue.devandroid.tareasasincronas;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MyService extends Service {
    public MyService() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String url = intent.getStringExtra(MainActivity.URL_LOAD);
        new DescargarCodigoPaginaWebTask().execute(url);
        return Service.START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private class DescargarCodigoPaginaWebTask extends AsyncTask<String, Void, String> {

        OkHttpClient client = new OkHttpClient();

        private String run(String url) throws IOException {
            Request req = new Request.Builder()
                    .url(url)
                    .build();

            Response res = client.newCall(req).execute();
            if (res.isSuccessful()) {
                return res.body().string();
            } else {
                return "Ocurrió un error";
            }
        }

        @Override
        protected String doInBackground(String... urls) {
            try {
                return run(urls[0]);
            } catch (IOException e) {
                return "Upss.";
            }
        }

        @Override
        protected void onPostExecute(String htmlString) {
            Intent i = new Intent();
            i.setAction(MainActivity.ACTION_DATOS_OK);
            i.putExtra(MainActivity.EXTRA_HTML, htmlString);
            sendBroadcast(i);
        }
    }
}
