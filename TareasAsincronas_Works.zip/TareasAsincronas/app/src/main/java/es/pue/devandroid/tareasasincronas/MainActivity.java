package es.pue.devandroid.tareasasincronas;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.http2.Header;

public class MainActivity extends AppCompatActivity {
    public static final String URL_LOAD = "url_load";

    public static final String ACTION_DATOS_OK = "es.pue.devandroid.tareasasincronas.ACTION_DATOS_OK";
    public static final String EXTRA_HTML = "HTML_RECEIVED";

    BroadcastReceiver receiver;

    TextView tvData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvData = findViewById(R.id.tvCode);

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                tvData.setText(intent.getStringExtra(EXTRA_HTML));
            }
        };
    }

    public void loadCode(View view) {
        Intent i = new Intent(this, MyService.class);
        i.putExtra(URL_LOAD, "http://square.github.io/okhttp/");
        startService(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver, new IntentFilter(ACTION_DATOS_OK));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }
}
