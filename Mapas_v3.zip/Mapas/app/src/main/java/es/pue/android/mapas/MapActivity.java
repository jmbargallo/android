package es.pue.android.mapas;

import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MapActivity extends AppCompatActivity {

    Button btnMap;

    //datos
    List<String> ciudades = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        Intent i = getIntent();
        Parcelable datosParcelable = i.getParcelableExtra("datosG");
        final DatosGeo dGeo = (DatosGeo) datosParcelable;

        btnMap = (Button)findViewById(R.id.btnMap);

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMap(Double.valueOf(dGeo.getLatitud()),
                            Double.valueOf(dGeo.getLongitud()));
            }
        });

        //generra info de ciudades
        ciudades.add("Barcelona");
        ciudades.add("Basilea");
        ciudades.add("Berlin");
        ciudades.add("Madrid");
        ciudades.add("Lucerna");

        ListView listaCiudades = (ListView) findViewById(R.id.lstCities);
        //creacion de adaptador
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                                android.R.layout.simple_list_item_1,
                                                                ciudades);

        listaCiudades.setAdapter(adapter);

    }
    private void showMap(double latitude, double longitud){

        Intent i = new Intent();
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse("geo:" + latitude + "," + longitud));
        startActivity(i);
    }
}
