package es.pue.android.mapas;

import android.os.Parcel;
import android.os.Parcelable;

public class DatosGeo implements Parcelable {
    private String longitud;
    private String latitud;

    protected DatosGeo(Parcel in) {
        longitud = in.readString();
        latitud = in.readString();
    }

    public static final Creator<DatosGeo> CREATOR = new Creator<DatosGeo>() {
        @Override
        public DatosGeo createFromParcel(Parcel in) {
            return new DatosGeo(in);
        }

        @Override
        public DatosGeo[] newArray(int size) {
            return new DatosGeo[size];
        }
    };

    public String getLongitud() {
        return longitud;
    }

    public String getLatitud() {
        return latitud;
    }

    public DatosGeo(String longitud, String latitud) {
        this.longitud = longitud;
        this.latitud = latitud;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(longitud);
        dest.writeString(latitud);
    }
}
