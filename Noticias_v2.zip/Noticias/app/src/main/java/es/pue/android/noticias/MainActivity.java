package es.pue.android.noticias;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import es.pue.android.noticias.model.New;

public class MainActivity extends AppCompatActivity {

    private RecyclerView newsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<New> news = new ArrayList<>();
        news.add(new New("Curso Android activo",
                            "Se esta celebrando una nueva sesion del curso android ya que hoy es martes",
                            "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8PDxIQEBASEBMQEBIQEBUVEBAWEBAQFBEWFhcRFRUYHSggGBolHRUWITEhJSkrLy4uGB8zODMtNzQtLisBCgoKDg0OGxAQGi0iHyUwLS0tKy0tMC0tLSstKy0tLS0tLS0tKy0tLS0uLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAK4BIgMBEQACEQEDEQH/xAAbAAEAAwEBAQEAAAAAAAAAAAAABAUGAwIBB//EAEMQAAIBAgIFBBAEBQQDAAAAAAABAgMRBAUGEiExURNhcdEUFiIzNEFTcnOBkZKTobLBMlSxwiNDYoKzY4Ph4hVCUv/EABoBAQADAQEBAAAAAAAAAAAAAAACAwQBBQb/xAA0EQEAAgECAwUFBwQDAAAAAAAAAQIDBBEFEjETIUFxkTNRUoHBFSIyNFNhsRQkcqEjQtH/2gAMAwEAAhEDEQA/AP3EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAzWvOkoVF+CMv4qtt1Hs1l0bzLqsl8cReOkdfJyU2Ek1dbU9q6DTE798OvR3cAOWJrxpwlOWxRV31FeTJFKzafAnuccslUlTUqn4ptytb8MXtUfUivTze1ItfrJCWaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABX5tmFKlBqp3TkmtRb5J7PUjJqtRjxV2v1nwcmWVWbVlBU4zcYx2K1ta3iTlzbjwP63LFeSs7QhvKLOvOW+cn0ybM85Lz3zafVzd9p4mpH8M5rolI7XLkrO8Wn1N5TFm9SWrGs+UhGalJbFKVtyb8aNMa29tq5O+rvM12BxtOtHWg78V44vg0fQ4c9MteasrN0kvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIWbY9UKbnve6K4y6vGZdVqIw4+afk5M7MTUqSqzvJ3lNq7fFu3qR8xNrZr/envlXvvKZm+VPD6ndqWvfxWaa9e406vSf0+3fvu7NdlcYkQCzwOUOrRlV10tXWsrb9VXd3fYb8GinLinJFttkojuQ8Fi50ZqcH0rxSXBmbBmthvzVcidm7wmJjVhGcd0lfofjXqPqsWWMlItHitdi0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkNKcQ5VtTxU4r3pbX9j5zimTmy8nuQspjzUHqc5StrNuysrtuy4K5K1rW6zu7u8kXAD1Gckmk2k96Tdn0rxkotMRtE9zryRcaPRHEPu6fRNfo/se3wnJ+KnzTo0p7SYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAg5jmlOglr3be6K3tceYyajV0wR97r7nJnZxy7O6VeWotaMvEpW29DRDT6/HmnaO6SLbqnNaGGlXm515Rk2rrk20ti2XPO1ePTzmmb3mJ8kZiETsXB/mZfCl1GfsdL+pPo5tB2Lg/zM/hS6h2Ol/Un0NoOxcH+Zn8KXUOx0v6k+htB2Lg/zM/hS6h2Ol/Un0NoOxcH+Zn8KXUOx0v6k+htB2Lg/wAzP4Uuodjpf1J9DaFlkFHDxrN0q0qktR3Tg1suttzboKYK5fuX3nb3bJRt4JeM0go05OCUptOz1bWT4Xb2mnNxLFjty9SbRCdgMdTrx1oPmae9Pg0asGopmrzVdid0ovdAAAAAAAAAAAAAAAAAAAAAAAAAAAAYrSOTeJnzKCXRqJ/dnzHEZ/uJ+X8K7dULBO1Wm1vVSH1IzYJ2yVn93I6pGeeE1fOX0ou13t7Oz1QTIiAAAAABa6OO1WbXioz+x6HDp/5Lf4z9Eqqo8/fxlyV7ojL+LNf6d/ZJdZ63CJ/5Jj9vqlRqz300THZjRoK9Wajfctrk+hLaUZdRjxRvednJtEdVd21YXjP4bMn2pp/fPor7Wr7DSjCtpJzu2ku4e9ux2OJ4LTERv3/s72tVxOaim5NJLa23sSN82iI3mdlk9ypq6TYSLtruXmwk17bWMV+Jaes7b7/JXOWsPWH0jwk3blNV/wBUZRXtew7j4jgvO3Nt5uxkrPisq9eMISm/wxi5O23YlfYa7XitZvPRKZ2jdT9tWF4z9xmD7V0/vn0V9rV6jpThH/7TXTTlb5HY4pp58Z9DtarTC4qnVjrU5Ka4p7uZ8Dbjy0yRvSd1kTv0Qsfn1ChPk562sknsi2rPnM2bXYsNuW2+/kjbJFZ2lG7asLxn7jKvtTB759HO1ql4HO8PXlqwn3XijJOLfRfeX4dbhyztWe92t4nosZSSV3ssapnaN5TVFfSTCQduUcvNjKS9u4w5OI6ek7c2/khOSseL1htIsLUdlU1W/wD6i4r2vYdx8RwXnaLepGSs+KzqVFGLk90U5PoSua5tEV5k0LLM3pYnW5PW7izd4tb72/RlGDV482/J4I1vFuiF21YXjP3GUTxTBE7d6Ha1fVpTheM1/tyOfamn98+h2tVlgsfSrK9OalbfxXSntRsxZ8eWN6Tusi0T0Si50AAYnSLwqp/Z/jifMcR/MW+X8Qrt1QsJ3yn6SH1Iy4vaV84chJzzwmr5y+lF+u/MWJ6oJkcAAAAAAtNHe+z9DU+xv4d7S3+M/RKqqR5/givdEe/T9H+5Hr8J9pPl9UqNXJnvT3d6xg8uw/Z2KnKo3q7Zu2/VvaMVw3/I+bwY51eomb9Gasc9mpjo9hF/JXrcm/1PYjQaf4YXdnX3MxpBhKdHF04U4qEbUpWV97qPbt6EeRrcVMeorFI26fyoyREWjZY6cYmSjTpp2jLWnLn1bWXzZq4vkmK1pHjvMp5pnol5bo3h404upHlJOKcm3K12tySe4v0/DsMUibRvKdcVYhHz7R+hCjOpSjqOC1rXbjJLerPcVa3QYoxzakbTCN8cbbw66J1OVw06c+6jGTht8cHFPV+bJ8NvOXBNb+Xydx99dpTu1/CeRj7ZdZp/oNP8EJdnX3PFXRzCSVuS1eeMpJr5nLcP08xty7HZ1Z7LFLCY/kr3jKXJv+qMleLtx2r5nk6ffTars9+6VVd6X2anF5XhqstapCMpWSu272XrPZy6fBktzXiJldNaz1cP/B4LyUPefWQ/o9N8MOclGWz6hSoYmKw73KMrKV9WetuT9mw8bWUpiz17L9unmovERb7q301xco06dNOyqXc+eMbdz0XfyNvFc1q0rSPHr5LMtto2dso0boKnGVWOvOUVJ3bUY3V7JIs03DcUUibxvLtccbd7ln2j1GNGVSlHUlBOTV24yS3qz3MhrOH4oxzakbTDl8cbbwaOYuU8HVhJ35JSjHzXBtL1bRoMs301qz4b+hjtvWXDQX+d0U/3lfCI35/l9XMPiuu1/CeRj7ZdZ6M6HT/BCzs6+58no9hGrcil0Smn+pydBp/hg7OvuZjFUXgMZHUb1e5kuLg3ZxfHc/keNkpOk1Mck930UzHJbubtH0sNL6AAxOkXhVT+z/HE+Y4j+Yt8v4hXbqhYTvlP0kPqRlxe0r5w5CTnnhNXzl9KL9d+YsT1QTI4AAAAABaaO99n6Gp9jfw72lv8Z+iVVUjz/BFe6I9+n6P9yPX4T7SfL6pUauSPemN42WMLkeJjg8VONXuVtpt8GpXT6Os+c0eWNPqLRfuZ6Ty2ndsY5jQauq1P349Z70Z8U98Wj1X80MnpU08bTa2pwpW+JI8TiM/3NZ8v5Z8n4nbTv8VLzKn6xJ8Y/FVLN1hrMP8Agj5sf0Pcp+GF0dEPP/Ba3opfoZ9Z7C/kjf8ADKo0JklRqtuyVS7b3Jai2mDhE7Y7TPv+iGH8K+7PoeVp+/HrPU7bH8Ueq3eHitmmHgrutTsv64t+xEbajFWN5tHqc0MlhKnZWYqpFPVU1PohBJJvpaXtPExWnUavnjpv/pRE8191znGjnZNV1eVUO5jG3J33c90b9Vw+c+Tni2yd8fNPVB7TP9dfC/7Gf7In40ex/dVrDPB4uEaijNRlGXjs4t7JLnX2MMYp02oiL9/ehty22lcab4duFOot0XKEubWtZ/L5m/i+Petbx5eqzNHduscmzujUpRUpxhOMVGSk0tqVrq+9GrS6zFfHETO0pUyRMOOkOc0VRnThOM5zi4JRd9VPY22txDXazHXFNazvM+5y94iETRnDuODrTf8AMUtXnjGDV/bcp4fjmunvafH/AMcxxtSXjQTfW6Kf7yPCP+/ycw+LSdn0PK0/fj1nrdvj+KPVdvD5PMaCV3Wp+/HrOW1GKI3m0epzQxubYhY3GQjT2x7mmnxSk3KXRtfsPB1OT+p1MRTviNme081o2btH0cNL6dADE6ReFVP7PoifMcR/MW+X8K7dULCd8p+kh9SMuH2lfOHISc88Jq+cvpRfrvzFieqCZHAAAAAALTR3vs/Q1Psb+He0t/jP0SqqkYEV7oj36fo/3I9bhPtJ8kqNYe+sVuZ5JRxG2aaklbWi7StwfH1mTPo8WbvtHehakWVT0NpeVn7IdRing+Of+0/6Q7GEzG6OxqzhN1JLk4wgklGz1He5fl4fXJatpnpt/pKccTO7rnWRxxTi5TlDUUkrJO+tbj0Fmr0UaiYmZ6O2pFpWlONklwSXsRsiNo2TccdhlVpzpt2U4uLa3q5Xmx9pSaT4uTG/cgYHI40aNWipyaq3u2ldXjq7DPh0VceO2OJ7pRikRGyv7TqflZ+7AyfY2P4kOxj3vUND6V9tWo/VBfYRwfF7zsYXOXZbSw6apxtfe27yl0s9DDpseGNqQsrWK9Ew0JAFPnGRRxM1NzlBxjq7Etu1vx9Jh1WhrntFpnbZXbHFp3WlSjGUXGSUk1Zp7muc1zSJryz3wsUWI0SoSd4ynDmuml7Vf5nm34ThnpvCqcMS+4bRPDxacnOpbxNpR+RLHwrDSd53kjDELudBODpruU4uKtbYrW2I9CaRy8sLJjeNlfk2SxwuvqzlPXUVtSVtW/DpMul0VcEWiJ33RrSKq3tOp+Vn7sDLPCKTMzzShOGJ8X1aHUvKz9kF9jn2Pj+KTsY962yzJ6OH2wj3TVnJu8rcOb1G7BpMWH8MLK0ivRYGpIAAUWeZK60uUptKVrST3Stud+J5Wt0M5rc1OqMxuj5Vo/ONRTqtJRd1FO7bW674FGl4bat4tl8HIqqs88Jq+cvpRh10/wBxZGeqCZHAAAAAALjRZXrv0cv1iejwuN80x+0/RKvV0xmjlVTfJasot7LuzjzMszcLvzfc6dXZqt8jyrsdNyac5b7bkl4kejotJ2ETNuspRGy1N7oAAAAAAAAAAAAAAAAAAAAAAAAAAAAB8ObDI6SYCcasqqTcZ2baX4Wlaz9h89xHTXjJOSOkq7R3qa55u0ohwLndgOT3OgcLndho9FsBOMnVknFOOrG62u7Tb6Nh7PC9PaszkmNvBOsNKe2mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD40c2FVpNFdjS86H1I8/iVY7Ce5y3RjT5xU1eia/gy9I/pie9wqInFO8eKyvRF0vVnS6J/tKOLRETXb93LM8eOg3mUxXIUvRQ+lH1elrE4a93gtjol2NTr6AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACq0n8Gl50PrR5/E/wAvLlujGHzaprNEu8S9I/pie/wr2M+ayvRF0w30uif7Sji/Wvz+jlmdPGQb3KfB6XoofSj63S+xr5Qtjolmh0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABxxeHjVhKEt0lbnXBoqzYq5KTS3iMy9GautZTg48e6vbzf8Ak8SeE5ObunuQ5Gjy/BxoU1CO221vxtvez2dPhjFTlhOI2cc3y1YiFr6sou8XwfB8xXq9LGeu3jHRyY3UmH0ZqOX8SUVG+3VbcmuCuth5ePhN+b789yMUainBRSSVkkklwSPdrWKxEQm9EgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//Z",
                            "Hoy",
                            ""
                ));
        news.add(new New("Curso iOS activo",
                "Se esta celebrando una nueva sesion del curso ios ya que hoy es martes",
                "https://images.tenorshare.com/es/ios-12/ios-apple.jpg",
                "Hoy",
                ""
        ));

        newsList = (RecyclerView) findViewById(R.id.list_news);
        newsList.setLayoutManager(new LinearLayoutManager(this));

        //set adapter
        NewsAdapter adapter = new NewsAdapter(news);
        newsList.setAdapter(adapter);



    }
}
