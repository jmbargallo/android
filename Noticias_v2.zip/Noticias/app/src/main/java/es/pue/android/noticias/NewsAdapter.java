package es.pue.android.noticias;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import es.pue.android.noticias.model.New;

public class NewsAdapter
        extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {

    public static final String CLAVE_URL = "url_data";

    private List<New> news;

    public NewsAdapter(List<New> news){
        this.news = news;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.new_item,
                                viewGroup,false);

        NewsViewHolder holder = new NewsViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder newsViewHolder, int i) {
        final New n = news.get(i);
        Glide.with(newsViewHolder.image.getContext())
                .load(n.getImageUrl())
                .into(newsViewHolder.image);
        newsViewHolder.title.setText(n.getTitle());
        newsViewHolder.content.setText(n.getDetails());
        newsViewHolder.itemView.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //TODO:lanzar detalle
                        Context ctx = v.getContext();
                        Intent i = new Intent(ctx,DetailActivity.class);
                        i.putExtra(CLAVE_URL,n.getUrlToNew());
                        ctx.startActivity(i);
                    }
                });

    }

    @Override
    public int getItemCount() {
        return this.news.size();
    }

    public static class NewsViewHolder extends
                                RecyclerView.ViewHolder {

        ImageView image;
        TextView title;
        TextView content;


        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.imgNew);
            title = (TextView)itemView.findViewById(R.id.tvTitle);
            content = (TextView)itemView.findViewById(R.id.tvDetail);
        }
    }
}
