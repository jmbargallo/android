package es.pue.android.camara;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnTakePhoto;
    private Button btnSendEmail;
    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTakePhoto = (Button)findViewById(R.id.btnTakePhoto);
        image = (ImageView)findViewById(R.id.imageView);

        //asociar un listener al widget boton
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //descifrar view...
                Button button = (Button) v;
                //si es un botton con id tal o cual...

                switch (button.getId()){
                    case R.id.btnTakePhoto:
                        hacerFoto();
                        break;
                    case R.id.btnSendEmail:
                        enviarCorreo("riardo@pue.es",
                                    "Curso Android");
                        break;
                    default:
                }
            }
        };
        btnTakePhoto.setOnClickListener(listener);

        //boton envio correo
        btnSendEmail = (Button)findViewById(R.id.btnSendEmail);
        btnSendEmail.setOnClickListener(listener);


    }

    private void hacerFoto(){
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null){
            startActivityForResult(i,1);
        }
    }

    private void enviarCorreo(String destino,
                                String motivo){

        Intent i = new Intent(Intent.ACTION_SENDTO);
        i.setData(Uri.parse("mailto:" + destino));
        i.putExtra(Intent.EXTRA_SUBJECT,motivo);

        startActivity(i);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 1 && resultCode == RESULT_OK){
            Bundle extras = data.getExtras();
            Bitmap imgBmp = (Bitmap)extras.get("data");
            image.setImageBitmap(imgBmp);
        }
    }

    public void gotoSecondActivity(View view) {

        Intent i = new Intent(this,SecondActivity.class);
        i.putExtra("name","Ricardo");
        startActivity(i);

    }
}
