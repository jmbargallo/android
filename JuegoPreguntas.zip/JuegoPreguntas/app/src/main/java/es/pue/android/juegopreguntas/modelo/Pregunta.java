package es.pue.android.juegopreguntas.modelo;

public class Pregunta {

    private int enunciado;
    private boolean respuestaCorrecta;

    public int getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(int enunciado) {
        this.enunciado = enunciado;
    }

    public boolean isRespuestaCorrecta() {
        return respuestaCorrecta;
    }

    public void setRespuestaCorrecta(boolean respuestaCorrecta) {
        this.respuestaCorrecta = respuestaCorrecta;
    }

    public Pregunta(int enunciado, boolean respuestaCorrecta) {
        this.enunciado = enunciado;
        this.respuestaCorrecta = respuestaCorrecta;
    }
}
