package es.pue.android.juegopreguntas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import es.pue.android.juegopreguntas.modelo.Pregunta;

public class MainActivity extends AppCompatActivity
                            implements View.OnClickListener {

    Button btnTrue;
    Button btnFalse;
    Button btnNext;
    TextView tvQuestion;

    private int indicePregunta = 0;

    //pregntas
    List<Pregunta> preguntas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTrue = (Button)findViewById(R.id.btnTrue);
        btnFalse = (Button)findViewById(R.id.btnFalse);
        btnNext = (Button)findViewById(R.id.btnNext);
        tvQuestion = (TextView)findViewById(R.id.tvQuestion);

        //carga de preguntas
        Pregunta pregunta_1 = new Pregunta(R.string.pregunta_1,true);
        Pregunta pregunta_2 = new Pregunta(R.string.pregunta_2,true);
        Pregunta pregunta_3 = new Pregunta(R.string.pregunta_3,true);
        Pregunta pregunta_4 = new Pregunta(R.string.pregunta_4,true);
        Pregunta pregunta_5 = new Pregunta(R.string.pregunta_5,false);

        preguntas.add(pregunta_1);
        preguntas.add(pregunta_2);
        preguntas.add(pregunta_3);
        preguntas.add(pregunta_4);
        preguntas.add(pregunta_5);

        tvQuestion.setText(preguntas.get(indicePregunta).getEnunciado());

        //gestion botones
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //indicePregunta = indicePregunta + 1;
                indicePregunta = new Random().nextInt(preguntas.size());
                tvQuestion.setText(preguntas.get(indicePregunta).getEnunciado());
            }
        });

        btnTrue.setOnClickListener(this);
        btnFalse.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.btnTrue){
            verificarRespuesta(true);
        } else if (id == R.id.btnFalse) {
            verificarRespuesta(false);
        }
    }

    private void verificarRespuesta(boolean respuestaJugador){
        boolean respuestaCorrecta =
                preguntas.get(indicePregunta).isRespuestaCorrecta();

        int infoUsuario = R.string.respuesta_incorrecta;
        if (respuestaCorrecta == respuestaJugador){
            infoUsuario = R.string.respuesta_correcta;
        }
        Toast.makeText(this,infoUsuario,Toast.LENGTH_LONG).show();
    }
}
